"""
URL configuration for beadproj project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from main import views
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.homePage, name='index'),
    path('reg', views.registerPage, name='register'),
    path('log', views.loginPage, name='login'),
    path('aucs', views.auctions, name='auctions'),
    path('auction/<int:auction_id>/', views.auction, name='auction'),
    path('aucc',views.createAuction, name='createAuction'),
    path('bid/<int:auction_id>/',views.createBid, name='newbid'),
    path('logout/', views.logout_view, name='logout'),
    path('team/',views.ourTeam,name='team'),
    path('conns/',views.contactList,name='conns'),
    path('delivery/<int:auction_id>/', views.delivery_choice, name='delivery'),
    path('reviews', views.reviews_page, name='reviews'),


]
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)