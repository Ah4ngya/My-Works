from django.contrib import admin
from .models import Auction, Bid, Worker, Review, AuctionManager
# Register your models here.

@admin.register(Auction)
class AuctionAdmin(admin.ModelAdmin):
    list_display = ('name', 'created_by', 'target_price', 'instant_sale_price', 'end_time')
    list_filter = ('created_by', 'end_time')
    search_fields = ('name', 'description')
@admin.register(Bid)
class BidAdmin(admin.ModelAdmin):
    list_display =('amount','bidder','auction','created_at')
    list_filter =('auction','bidder')
    search_fields = ('auction','bidder')
@admin.register(Worker)
class WorkerAdmin(admin.ModelAdmin):
    list_display = ('full_name', 'user', 'is_worker', 'email', 'phone_number')
    list_filter = ('is_worker',)
    search_fields = ('full_name', 'user__username', 'email', 'phone_number')
    fields = ('user', 'full_name', 'is_worker', 'email', 'phone_number', 'profile_picture')


@admin.register(Review)
class ReviewAdmin(admin.ModelAdmin):
    list_display = ('title', 'user', 'rating', 'created_at')
    list_filter = ('rating', 'created_at')
    search_fields = ('title', 'content', 'user__username')

@admin.register(AuctionManager)
class WorkerAdmin(admin.ModelAdmin):
    list_display = ('full_name', 'user', 'is_auctionmanager', 'email', 'phone_number')
    list_filter = ('is_auctionmanager',)
    search_fields = ('full_name', 'user__username', 'email', 'phone_number')
    fields = ('user', 'full_name', 'is_auctionmanager', 'email', 'phone_number')


