from django.db import models
from django.utils import timezone
from datetime import timedelta
from django.contrib.auth.models import User

# Create your models here.



def default_end_time():
    return timezone.now() + timedelta(days=7)

class Auction(models.Model):
    ITEM_TYPES = [
        ('porcelain', 'Porcelain'),
        ('painting', 'Painting'),
        ('jewelry', 'Jewelry'),
    ]
    DELIVERY_OPTIONS = [
        ('shipping', 'Shipping'),
        ('in_person', 'In Person'),
    ]
    name = models.CharField(max_length=100)
    description = models.TextField()
    image = models.ImageField(upload_to='auction_images/', blank=True, null=True)  # optional
    created_by = models.ForeignKey(User, on_delete=models.CASCADE, related_name='auctions')
    start_time = models.DateTimeField(default=timezone.now)
    end_time = models.DateTimeField(default=default_end_time)
    target_price = models.DecimalField(max_digits=12, decimal_places=2)
    instant_sale_price = models.DecimalField(max_digits=12, decimal_places=2)
    itemType = models.CharField(max_length=20, choices=ITEM_TYPES)
    winner = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name='won_auctions')
    delivery_option = models.CharField(max_length=20, null=True, blank=True)  # 'shipping' or 'in_person'
    is_active = models.BooleanField(default=False)

    def end_auction(self, winner=None, delivery_option=None):
        """Ends the auction and records the winner/delivery choice."""
        self.winner = winner
        self.delivery_option = delivery_option
        self.end_time = timezone.now()
        self.save()

    @property
    def final_price(self):
        highest_bid = self.bids.order_by('-amount').first()
        return highest_bid.amount if highest_bid else None

    def __str__(self):
        return self.name

class Bid(models.Model):
    amount = models.DecimalField(max_digits=12, decimal_places=2)
    bidder = models.ForeignKey(User, on_delete=models.CASCADE, related_name='bid')
    auction = models.ForeignKey(Auction, on_delete=models.CASCADE, related_name='bids')
    created_at =  models.DateTimeField(default=timezone.now)

    def __str__(self):
        return self.bidder.username


class Worker(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='worker_profile')
    is_worker = models.BooleanField(default=True)
    full_name = models.CharField(max_length=150)
    email = models.EmailField(blank=True, null=True)
    phone_number = models.CharField(max_length=20, blank=True, null=True)
    profile_picture = models.ImageField(upload_to='worker_profiles/', blank=True, null=True)

    def __str__(self):
        return self.full_name

class Review(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='reviews')
    title = models.CharField(max_length=100)
    content = models.TextField()
    rating = models.PositiveSmallIntegerField(default=5)  # 1–5 stars
    created_at = models.DateTimeField(default=timezone.now)

    def __str__(self):
        return f"{self.title} by {self.user.username}"

class AuctionManager(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='manager_profile')
    is_auctionmanager = models.BooleanField(default=True)
    full_name = models.CharField(max_length=150)
    email = models.EmailField(blank=True, null=True)
    phone_number = models.CharField(max_length=20, blank=True, null=True)

    def __str__(self):
        return self.full_name