from django.test import TestCase
from django.contrib.auth.models import User
from django.utils import timezone
from main.models import Auction, Bid

class AuctionTests(TestCase):

    def setUp(self):
        # Teszt user és manager létrehozása
        self.user = User.objects.create_user(username="user1", password="pass123")
        self.manager = User.objects.create_user(username="manager", password="pass123")

        # Ha van manager_profile, azt itt kell létrehozni:
        # manager_profile = ManagerProfile.objects.create(user=self.manager, is_auctionmanager=True)

    def test_auction_creation(self):
        auction = Auction.objects.create(
            name="Teszt tárgy",
            description="Ez egy teszt aukció.",
            created_by=self.user,
            target_price=1000,
            instant_sale_price=5000,
            itemType="painting"
        )

        self.assertEqual(auction.name, "Teszt tárgy")
        self.assertEqual(auction.created_by.username, "user1")
        self.assertFalse(auction.is_active)       # Kezdetben még nem aktív


    def test_bid_creation(self):
        auction = Auction.objects.create(
            name="Teszt aukció",
            description="Licit teszt",
            created_by=self.user,
            target_price=1000,
            instant_sale_price=5000,
            itemType="painting"
        )

        bid = Bid.objects.create(
            amount=1500,
            bidder=self.user,
            auction=auction
        )

        self.assertEqual(bid.amount, 1500)
        self.assertEqual(bid.bidder.username, "user1")
        self.assertEqual(bid.auction, auction)


    def test_manager_can_start_and_end_auction(self):
        auction = Auction.objects.create(
            name="Indítható aukció",
            description="Manager test",
            created_by=self.user,
            target_price=1000,
            instant_sale_price=3000,
            itemType="painting"
        )

        # Manager elindítja
        auction.is_active = True
        auction.start_time = timezone.now()
        auction.save()

        self.assertTrue(auction.is_active)

        # Licit létrehozása
        bid = Bid.objects.create(
            amount=2500,
            bidder=self.user,
            auction=auction
        )

        # Manager lezárja
        highest_bid = auction.bids.order_by('-amount').first()
        auction.is_active = False
        auction.end_time = timezone.now()
        auction.winner = highest_bid.bidder
        auction.save()

        self.assertFalse(auction.is_active)
        self.assertEqual(auction.winner.username, "user1")


    def test_only_manager_can_start_auction(self):
        auction = Auction.objects.create(
            name="Manager start test",
            description="Test",
            created_by=self.user,
            target_price=1000,
            instant_sale_price=5000,
            itemType="painting"
        )

        # Normal user probál indítani
        auction.is_active = False
        auction.save()

        self.client.login(username="user1", password="pass123")
        response = self.client.post(f"/auction/{auction.id}/", {"action": "start"})

        auction.refresh_from_db()
        self.assertFalse(auction.is_active)   # Normal user nincs jogusultsága


    def test_instant_sale_assigns_winner(self):
        auction = Auction.objects.create(
            name="Instant sale test",
            description="Instant test",
            created_by=self.user,
            target_price=1000,
            instant_sale_price=3000,
            itemType="painting",
            is_active=True,
        )

        self.client.login(username="user1", password="pass123")

        #bid létrehozása ami nagyobb v egyenlő mint a kiadott instant sale price
        bid = Bid.objects.create(
            amount=3000,
            bidder=self.user,
            auction=auction
        )

        # Instant sale működése
        auction.winner = bid.bidder
        auction.is_active = False
        auction.save()

        auction.refresh_from_db()

        self.assertFalse(auction.is_active)
        self.assertEqual(auction.winner.username, "user1")
