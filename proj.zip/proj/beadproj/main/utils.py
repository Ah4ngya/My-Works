import time
from main.models import Auction

def delete_after_delay(auction_id):
    time.sleep(120)  # 2 minutes
    try:
        auction = Auction.objects.get(id=auction_id)
        auction.delete()
    except Auction.DoesNotExist:
        pass
