from django.shortcuts import render, redirect
from django.contrib import messages
from django.contrib.auth.hashers import make_password , check_password
from .models import User , Auction , Bid , Worker , Review
from django.shortcuts import render, get_object_or_404
from django.utils import timezone
from datetime import timedelta
from django.contrib.auth import get_user_model, logout
from django.contrib.auth.decorators import login_required
import threading
from main.utils import delete_after_delay
from django.contrib.auth import authenticate, login
from decimal import Decimal, InvalidOperation




# Create your views here.

def login_required_manual(view_func):
    def wrapper(request, *args, **kwargs):
        if 'user_id' not in request.session:
            return redirect('login')  # your login URL name
        return view_func(request, *args, **kwargs)
    return wrapper



def homePage(request):
    reviews = Review.objects.all().order_by("-created_at")
    context = {'reviews':reviews}
    return render(request,'index.html', context)

def registerPage(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        email = request.POST.get('email')
        password = request.POST.get('password')



        if not username or not email or not password:
            messages.error(request, "All fields are required.")
            return render(request, 'registerpage.html')

        if User.objects.filter(username=username).exists():
            messages.error(request, "Username already exists.")
            return render(request, 'registerpage.html')

        if User.objects.filter(email=email).exists():
            messages.error(request, "Email already registered.")
            return render(request, 'registerpage.html')


        user = User(
            username=username,
            email=email,
            password=make_password(password),

        )
        user.save()

        messages.success(request, "Account created successfully! You can now log in.")
        return redirect('login') 

    return render(request, 'registerpage.html')

def loginPage(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('index')
        else:
            messages.error(request, "Invalid credentials")
    return render(request, 'loginpage.html')

def logout_view(request):
    logout(request)
    return redirect('index')

def auctions(request):
    auctions = Auction.objects.all().order_by('-start_time')
    
    if request.method == 'GET':
        query = request.GET.get('q','')

        if query:
            auctions = Auction.objects.filter(name__icontains=query)
        else:
            auctions = Auction.objects.all().order_by('-start_time')
    
    user_auctions = None
    if request.user.is_authenticated:
        user_auctions = Auction.objects.filter(created_by=request.user)
    context = {'auctions':auctions,'user_auctions':user_auctions}
    return render(request,'auctions.html', context)


def auction(request, auction_id):
    auction = get_object_or_404(Auction, id=auction_id)
    highest_bid = auction.bids.order_by('-amount').first()
    
    if request.method == 'POST':
        action = request.POST.get("action")
        if not hasattr(request.user, "manager_profile") or not request.user.manager_profile.is_auctionmanager:
            messages.error(request, "Nincs jogosultságod az aukció kezeléséhez.")
            return redirect('auction', auction_id=auction.id)
        
        if action == "start":
            auction.is_active = True
            auction.start_time = timezone.now()
            auction.save()

        if action == "end":
            auction.is_active = False
            auction.end_time = timezone.now()
            auction.winner = highest_bid.bidder
            auction.save()

  

    context = {
        
        'auction': auction,
        'highest_bid': highest_bid.amount if highest_bid else 0
    }

    return render(request, 'auction.html', context)


@login_required(login_url='login')
def createAuction(request):
    if request.method == 'POST':
        try:
            target_price = Decimal(request.POST.get('target_price', '0'))
            instant_sale_price = Decimal(request.POST.get('instant_sale_price', '0'))
        except InvalidOperation:
            messages.error(request, "Invalid price format. Please use numbers only, e.g., 100.50")
            return render(request, 'auctioncreation.html')
        name = request.POST.get('name')
        description = request.POST.get('description')
        target_price = request.POST.get('target_price')
        instant_sale_price = request.POST.get('instant_sale_price')
        end_time = request.POST.get('end_time')
        image = request.FILES.get('image')
        itemType = request.POST.get('itemType')
        
        auction = Auction(
            name=name,
            description=description,
            target_price=target_price,
            instant_sale_price=instant_sale_price,
            end_time=end_time,
            image=image,
            created_by=request.user,
            itemType = itemType
        )
        auction.save()
        print("Saved auction with ID:", auction.id)

        messages.success(request, "Auction created successfully!")
        return redirect('auction', auction_id=auction.id)
    return render(request, 'auctioncreation.html')
    
    


@login_required(login_url='login')
def createBid(request, auction_id):
    auction = get_object_or_404(Auction, id=auction_id)
    
    if request.method == 'POST':
        if auction.created_by == request.user:
            messages.error(request, "Nem licitálhatsz a saját aukciódra!")
           
            return redirect('auction', auction_id=auction.id)

        try:
            amount = int(request.POST.get('amount', 0))
        except ValueError:
            messages.error(request, "Invalid bid amount.")
            return redirect('auction', auction_id=auction.id)

        highest_bid = auction.bids.order_by('-amount').first()
        if highest_bid and amount <= highest_bid.amount:
            messages.error(request, "Bid must be higher than the current highest bid.")
            return redirect('auction', auction_id=auction.id)

        if auction.is_active != True:
            messages.error(request, "The auction has already ended")
            return redirect('auctions')
        # Save valid bid
        bid = Bid(amount=amount, bidder=request.user, auction=auction)
        bid.save()
        # Check for instant sale
        if amount >= auction.instant_sale_price:
            auction.winner = request.user
            auction.end_time = timezone.now()
            auction.is_active = False
            auction.save()
            return redirect('delivery', auction_id=auction.id)
        
        return redirect('auction', auction_id=auction.id)
    
    return render(request, 'bid.html', {'auction': auction})

def ourTeam(request):
    ourteam = Worker.objects.all()
    context = {'ourteam':ourteam}
    return render(request, 'ourteam.html', context)

def contactList(request):
    return render(request, 'contacts.html')

@login_required(login_url='login')
def delivery_choice(request, auction_id):
    auction = get_object_or_404(Auction, id=auction_id, winner=request.user)

    if request.method == 'POST':
        option = request.POST.get('delivery_option')
        if option in ['shipping', 'in_person']:
            auction.delivery_option = option
            auction.is_active = False
            auction.end_time = timezone.now()
            auction.save()

            
            threading.Thread(target=delete_after_delay, args=(auction.id,)).start()

            return render(request, 'delivery.html', {'auction': auction})

    return render(request, 'delivery.html', {'auction': auction})

from django.shortcuts import render, redirect
from django.contrib import messages
from .models import Review

@login_required(login_url='login')
def reviews_page(request):
    if request.method == 'POST':
        title = request.POST.get('title')
        content = request.POST.get('content')
        rating = request.POST.get('rating')

        if title and content and rating:
            review = Review.objects.create(
                user=request.user,
                title=title,
                content=content,
                rating=rating
            )
            messages.success(request, "Köszönjük a visszajelzését!")
            return redirect('reviews')
        else:
            messages.error(request, "Kérjük, töltse ki az összes mezőt!")

    reviews = Review.objects.order_by('-created_at')
    return render(request, 'reviews.html', {'reviews': reviews})

